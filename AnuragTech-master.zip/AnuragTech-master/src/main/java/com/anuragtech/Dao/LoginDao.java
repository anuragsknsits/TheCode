package com.anuragtech.Dao;



import com.anuragtech.Model.Login;

public interface LoginDao {
	public Login selectUser(Login login);
}

package com.anuragtech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSampleApplication.class, args);
	}
}

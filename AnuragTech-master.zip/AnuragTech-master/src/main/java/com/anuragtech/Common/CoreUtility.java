package com.anuragtech.Common;

public class CoreUtility {
	
	public static final String DEFAULT_SCHEMA = "DBO";
	

	public String getMonthDescription(int month)
	{
		String [] manths={"January","February","March","April","May","June","July","August","September","October","November","December"};
		return manths[month];
	}
	
	/**
	 * @author Ravising.Pardeshi
	 * @param arType
	 * @return
	 */
	
}

package com.anuragtech.Common;

public interface GlobalBase {
	
	public Object[] getMemberValues();
	public Object[] getPrimaryValues();
	
}

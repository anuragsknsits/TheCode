export class User {
    uname : string;
    emailId : string;
    password : string;
    mobileNo : string;
    }
